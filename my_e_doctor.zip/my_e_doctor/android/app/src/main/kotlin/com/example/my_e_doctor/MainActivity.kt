package com.example.my_e_doctor

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
